var isButtonAdded = false;
var targetTimeSeconds = timeToSeconds('08:20:00');
var dayMustTimeSeconds = timeToSeconds('07:00:00');
var dayExtraUseTimeSeconds = timeToSeconds('01:20:00');
function checkAndAddButton() {
    if(window.location.pathname !== "/time-entry") {
        var stickButton = document.getElementById("sticky-button");
        if (stickButton) {
            stickButton.remove(); 
            isButtonAdded = false;
        }
        return;
    }
    if(isButtonAdded) return;
    if(window.location.pathname === "/time-entry") {
        isButtonAdded = true;
        addButtonInBody('Calculate Time', 'sticky-button', '#007bff', 'white');
        document.getElementById('sticky-button').addEventListener('click', function () {
          alert(calculateTimeDifference());
        });
    }
}
function addButtonInBody(name, id, backgroudColor, color) {
  const button = document.createElement('button');
  button.id = id;
  button.textContent = name;
  document.body.appendChild(button);
  button.style.position = 'fixed';
  button.style.left = '20px';
  button.style.bottom = '20px';
  button.style.backgroundColor = backgroudColor;
  button.style.color = color;
  button.style.padding = '10px 20px';
  button.style.border = 'none';
  button.style.borderRadius = '5px';
  button.style.cursor = 'pointer';
  button.style.zIndex = '999';
}
if(window.location.host === "portal.inexture.com") {
    var timeEntryLoop = setInterval(checkAndAddButton, 2000);
}
function timeToSeconds(time) {
    let [hours, minutes, seconds] = time.split(':').map(Number);
    return hours * 3600 + minutes * 60 + seconds;
}
function secondsToTime(seconds) {
    let hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    let minutes = Math.floor(seconds / 60);
    seconds %= 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}
function calculateTimeDifference() {
  var table = document.getElementsByClassName("mrt-table")[0];
  var todayEntry = table.rows[1]
  let liveDurationSeconds = timeToSeconds(todayEntry.cells[todayEntry.cells.length - 2].innerText);
  var weekPreviosERTime = getExtraOrRemainOfWeek();
  var weekPreviosERTimeSecond = timeToSeconds(weekPreviosERTime);
  if(weekPreviosERTimeSecond > dayExtraUseTimeSeconds) weekPreviosERTimeSecond = dayExtraUseTimeSeconds;
  var weekPreviosERTimeString = "\n\n=> Time duration of previous days of this week : " + weekPreviosERTime;
  var diffSecond = targetTimeSeconds - liveDurationSeconds;
  var leaveTImeString = addSecondsToCurrentTime(diffSecond);
  var leaveTImeSecond = timeToSeconds(leaveTImeString)
  var leaveSecondPrevious = secondsToTime((weekPreviosERTime.includes("-")) ? leaveTImeSecond + weekPreviosERTimeSecond : leaveTImeSecond - weekPreviosERTimeSecond)
  return (liveDurationSeconds < targetTimeSeconds) ? 
    "=> Need to stay in office for : "+secondsToTime(targetTimeSeconds - liveDurationSeconds)+
    "\n\n=> You can leave at : "+ leaveTImeString + weekPreviosERTimeString +
    "\n\n=> You can leave at : "+ leaveSecondPrevious +" by using previous days time of this week." : 
    "=> You can leave now.\n\n => As your time is over for today.\n\n=> Your extra time is : "
    +secondsToTime(liveDurationSeconds - targetTimeSeconds)+"."+ weekPreviosERTimeString;
}
function addSecondsToCurrentTime(secondsToAdd) {
    let currentTime = new Date();
    currentTime.setSeconds(currentTime.getSeconds() + secondsToAdd);
    let hours = String(currentTime.getHours()).padStart(2, '0');
    let minutes = String(currentTime.getMinutes()).padStart(2, '0');
    let seconds = String(currentTime.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}
function getExtraOrRemainOfWeek() {
    var totalTimeTillNowString = document.querySelector('main div div .inexture-ScrollArea-root .inexture-ScrollArea-viewport div .inexture-Paper-root div .grid-cols-1 .inexture-Paper-root:nth-child(2) div:last-child p').textContent;
    let [hours, minutes, seconds] = totalTimeTillNowString.match(/\d+/g).map(Number);
    var weeklySeconds = (hours * 3600 + minutes * 60 + seconds);
    var attendedDays = Math.round(weeklySeconds / targetTimeSeconds);
    var targetWeekTillToday = (targetTimeSeconds * attendedDays);
    return (targetWeekTillToday < weeklySeconds) ? secondsToTime(weeklySeconds - targetWeekTillToday) : "-" + secondsToTime(targetWeekTillToday - weeklySeconds);
}