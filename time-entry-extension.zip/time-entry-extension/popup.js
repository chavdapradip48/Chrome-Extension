document.getElementById("openPortal").addEventListener("click", function() {
    chrome.tabs.create({ url: "https://portal.inexture.com/time-entry" });
});
