chrome.runtime.onInstalled.addListener(() => {
    console.log("Time Entry Helper Extension Installed!");
  });
  